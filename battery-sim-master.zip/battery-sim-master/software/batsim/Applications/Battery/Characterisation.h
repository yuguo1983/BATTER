#ifndef BATTERY_CHARACTERISATION_H_
#define BATTERY_CHARACTERISATION_H_

#include "app.h"

void Characterisation_Init();

#endif
