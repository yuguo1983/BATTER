#pragma once

#include "app.h"

void Scope_Init();
