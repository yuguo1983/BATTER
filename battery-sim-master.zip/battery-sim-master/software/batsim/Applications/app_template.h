/*
 * Template file, not actually used in the project.
 * Copy file when creating a new application and add app functionality
 */
#include "app.h"

void Template_Init();


