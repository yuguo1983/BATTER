#ifndef CHARGER_H_
#define CHARGER_H_

#include "app.h"

void Charger_Init();

#endif
