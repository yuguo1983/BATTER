#ifndef INFO_H_
#define INFO_H_

#include "app.h"

void Info_Init();

#endif
