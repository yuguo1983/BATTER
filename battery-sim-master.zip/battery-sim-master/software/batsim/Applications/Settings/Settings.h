
#ifndef SETTINGS_SETTINGS_H_
#define SETTINGS_SETTINGS_H_

#include <limits.h>
#include "gui.h"
#include "touch.h"

void settings_Init();

void settings(void *unused);



#endif /* SETTINGS_SETTINGS_H_ */
