
#ifndef BATTERY_SIMULATOR_H_
#define BATTERY_SIMULATOR_H_

#include "app.h"

void Simulator_Init();

#endif
