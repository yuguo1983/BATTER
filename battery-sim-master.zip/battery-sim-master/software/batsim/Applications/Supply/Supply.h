#ifndef SUPPLY_H_
#define SUPPLY_H_

#include "app.h"

void Supply_Init();


#endif
