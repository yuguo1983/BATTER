#ifndef INPUT_H_
#define INPUT_H_


#include "gui.h"
#include "touch.h"

BaseType_t input_Init();


#endif
